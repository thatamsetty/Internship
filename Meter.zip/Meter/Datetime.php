<html>
<body>
<center>
	<form method="POST" action="">
	<label for="Datetime">Date</label>
	<input type="Date" id="Datetime" name="Datetime"><br><br>
	<input type="submit">
    </form>
</body>
<style>
	table,th,td{
		border:1px solid red;
	}
</style>
</center>
<table style="width:50%;border-collapse: collapse;" >
	<h1>USER DETAILS</h1>
	<tr>
		<th>ID</th>
		<th>name</th>
		<th>mobile_no</th>
		<th>password</th>
		<th>address</th>
		<th>age</th>
		<th>Datetime</th>
		<th>Location</th>
		
	</tr>
<?php
if(isset($_POST['Datetime'])){
	$Date=$_POST['Datetime'];
	// echo$Date;
	// echo gettype($Date);
	$convert=strtotime($Date);
	// echo gettype($convert);
    $month=Date("m",$convert);
    $year=Date("Y",$convert);
    // echo$month;
    // echo$year;
    $year_month=$year.'-'.$month;
    // echo$year_month;
    $conn=mysqli_connect("localhost","thrinethra","12345678","meter");
    $select="select * from user where Datetime like'$year_month%'";
    $data=mysqli_query($conn,$select);
    while($row=mysqli_fetch_assoc($data)){?>
    <tr>
    <form method="POST" action="">
	<td><?php echo $row['user_id'];?></td>
	<td><?php echo $row['Name'];?> </td>
	<td><?php echo $row['mobile_no'];?></td>
	<td><?php echo $row['address'];?></td>
	<td><?php echo $row['password'];?></td>
	<td><?php echo $row['age'];?></td>
	<td><?php echo $row['Datetime'];?></td>
	<td><?php echo $row['Location'];?></td>
	
	
    </form>
    </tr>
<?php  }}?>
</table>
</html>




