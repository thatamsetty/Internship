<?php
$a=['vinoth',1,'hema'];
 echo '<h1>hello</h1>';
foreach($a as $c){
     echo "the value is:"$c.'<br>';?>
     <p>hi <?php echo $c;}?></p>



