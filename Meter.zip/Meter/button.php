<?php
$gender=$_POST['gender'];
// echo $gender;
$language=$_POST['language'];
// echo $language;
$state=$_POST['state'];
// echo $state;
?>
<style>
	table,th,td{
		border:1px solid blue;
	}
</style>
<table style="border-collapse: collapse;">
<tr>
<th>gender</th>
<th>language</th>
<th>state</ th>

</tr>
<tr>
<td><?php echo $gender;?> </td>
<td><?php echo $language;?></td>
<td><?php echo $state;?></td>

</tr>