<?php
$Device_info_id=$_POST['Device_info_id'];
echo $Device_info_id;
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$delete= "delete * from register where Device_info_id='$Device_info_id'";
$fetch=mysqli_fetch_assoc(mysqli_query($conn,$select)); // reading single row of data

 if(isset($fetch['Device_info_id'])){
	echo "are you sure";
	echo '<a href="whiledev.php"><button>Back to homepage</button></a>';
    }
 else{
	echo "deleted sucessfully";
	echo '<a href="whiledev.php"><button>Back to homepage</button></a>';
     }
?>