<body>	<center>
	<form method="POST" action="ddata1.php" style="width: 500px; border: 20px solid skyblue; border-radius: 19px;padding: 30px;background: beige;">
<table>
<tr>
<th><label for="">Device_name</label></th>
<td>
<?php
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select="select * from device_info";
$data=mysqli_query($conn,$select);?>
<select name="Device_info_id"><?php
while($row=mysqli_fetch_assoc($data)){?>

<option value="<?php echo $row['Device_info_id'];?>" ><?php echo $row['Device_name'];?></option>
<?php }?></td></tr>

</select>

<tr>
	<th><label for="month-year">Month-year</label></th>
	<td><input type="Date"  name="Datetime"></td>
</tr>

<tr>
	<th><label for="unit">unit</label></th>
	<td><input type="number" name="unit" id="unit"></td>
</tr>
<tr>
	<th></th>
	<td><input type="checkbox" name="" id="" min="0" step="1" oninput="caluclateprice()"></td>
</tr>
<tr>
	<th><label for="price">price</label>
	<td><input type="text" name="price" id="price" readonly></td>
</tr></table>
<th></th>
<tr><input type="submit" name="submit"><tr></form><br>
</center>
<script>
	function caluclateprice(){
		var unitsInput = document.getElementById("unit");
		var priceoutput = document.getElementById("price");

		var units = parseInt(unitsInput.value);
		var price=0;
		if(units<=100){
			price = units * 4.80;
		}
		else if(units<=200){
			price = 100 * 4.80 +(units-100) * 5.80;
		}
		else {
			price= 100*4.80+100*5.80+(units-200)* 6.80;
		}
		priceoutput.value="Rs." +price.toFixed(2);
	}
</script>


