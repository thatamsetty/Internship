<?php
$Device_info_id=$_POST['Device_info_id'];
echo $Device_info_id;
$Datetime=$_POST['Datetime'];
$unit=$_POST['unit'];
$price=$_POST['price'];
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select="select * from device_info where `Device_info_id`='$Device_info_id'";
$fetch=mysqli_fetch_assoc(mysqli_query($conn,$select));
$user_id=$fetch['user_id'];
$dn=$fetch['Device_name'];
$insert="insert into device_data (`Device_info_id`,`Device_name`,`user_id`,`Datetime`,`unit`,`price`) values('$Device_info_id','$dn','$user_id','$Datetime','$unit','$price')"; 
mysqli_query($conn,$insert);
echo $select;
mysqli_query($conn,$select);
?>
