<?php
$Device_info_id=$_POST['Device_info_id'];
echo $Device_info_id;
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$delete="delete from Device_info where Device_info_id='$Device_info_id'";
$query=mysqli_query($conn,$delete);
echo 'Deleted sucessfully';
?>
