<?php
$Device_name=$_POST['Device_name'];
echo $Device_name;
$Device_mac_id=$_POST['Device_mac_id'];
echo $Device_mac_id;
$Device_version_id=$_POST['Device_version_id'];
echo $Device_version_id;
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$insert="insert into `device_info`(`Device_name`,`Device_mac_id`,`Device_version_id`) values('$Device_name','$Device_mac_id','$Device_version_id')";
mysqli_query($conn,$insert);
?>