<?php
$Device_info_id=$_POST['Device_info_id'];
// echo $Device_info_id;

$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select="select * from device_info where  Device_info_id='$Device_info_id'";

$fetch=mysqli_fetch_assoc(mysqli_query($conn,$select));
?>
<html>
<body>


<table>
	<tr>

	

	<form method="POST" action="dupdate.php">
		<input type="hidden" name="Device_info_id" value="<?php echo $fetch['Device_info_id']; ?>">
		<td><input type="submit" name="operation1"value="update"></td>
	</form>

	<form method="POST" action="ddelete.php">
		<input type="hidden" name="Device_info_id" value="<?php echo $fetch['Device_info_id']; ?>">
		<td><input type="submit" name="operation2"value="delete" onclick="return checkdelete()"></td>
    </form>
	</tr>
</table>
<script>
	function checkdelete()
	{
		return confirm('Are you sure to delete the record');
	}
</script>
</body>
</html>
