	<center>
	<form method="POST" action="">

<tr>
<th><label for="Device_name">Device_name</label></th>
<td><select name="Device_name" id="Device_name" value="Device_name">
	<option value="select all">all</option>

<?php
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select1="select * from device_info";
$data=mysqli_query($conn,$select1);
while ($row=mysqli_fetch_assoc($data)){?>

<option ><?php echo $row['Device_name'];?> </option>
<?php }?>
</select>

</td>
</tr>
<tr>
	<th><label for="month-year">Month-year</label></th>
	<td><input type="Date"  name="Datetime"></td>
</tr>
<style>
	table,th,td{
		border:1px solid red;
	}
</style>
<center>
<table style="width:50%;border-collapse: collapse;" >
	<input type="submit"name="submit"></form>
	<h1>USER DETAILS</h1>
	<tr>
		<th>Device_info_id</th>
		<th>Device_data_id</th>
		<th>Device_name</th>
		<th>user_id</th>
		<th>Datetime</th>
		<th>unit</th>
		<th>price</th>
	</tr>


<?php
	if(isset($_POST['Datetime'])){
		$a=$_POST['Datetime'];
		$b=$_POST['Device_name'];
		$conn=mysqli_connect("localhost","thrinethra","12345678","meter");

        if($b=='select all'){
        	$select="select * from Device_data where `Datetime` like '$a%'";
        }
        else{
        	$select="select * from Device_data where `Datetime` like'$a%' and `Device_name`='$b'";
        }
        
        echo $select;
        $data=mysqli_query($conn,$select);
        while($row=mysqli_fetch_assoc($data)){?>
    <tr>
    	<td><?php echo $row['Device_data_id']?></td>
    	<td><?php echo $row['Device_info_id']?></td>
    	<td><?php echo $row['Device_name']?></td>
    	<td><?php echo $row['user_id']?></td>
    	<td><?php echo $row['Datetime']?></td>
    	<td><?php echo $row['unit']?></td>
    	<td><?php echo $row['price']?></td>
    </tr>
    <?php } }
    	else{

    		echo "testing";
    		$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
    	 $select="select * from Device_data";	
         $data=mysqli_query($conn,$select);
        while($row=mysqli_fetch_assoc($data)){?>
    <tr>
    	<td><?php echo $row['Device_data_id']?></td>
    	<td><?php echo $row['Device_info_id']?></td>
    	<td><?php echo $row['Device_name']?></td>
    	<td><?php echo $row['user_id']?></td>
    	<td><?php echo $row['Datetime']?></td>
    	<td><?php echo $row['unit']?></td>
    	<td><?php echo $row['price']?></td>
    </tr>

    <?php 	}
    }
    	?>
</center>
</table>


