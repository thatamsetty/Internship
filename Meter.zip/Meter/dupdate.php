<?php
$Device_info_id=$_POST['Device_info_id'];
// echo $Device_info_id;

$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select="select * from device_info where  Device_info_id='$Device_info_id'";

$fetch=mysqli_fetch_assoc(mysqli_query($conn,$select));
?>
<body>
	<table>
	
		<form method="POST" action="dupdate1.php">
		<h1>device info</h1>
		<input type="hidden" name="Device_info_id" value='<?php echo $fetch['Device_info_id']?>'>
        <th>Device_name</th>
        <td><input type="text" name="Device_name" value='<?php echo $fetch['Device_name']?>'></td><br><br>   
    <tr>
        <th>Device_mac_id</th>
        <td><input type="text" name="Device_mac_id" value='<?php echo $fetch['Device_mac_id']?>'></td><br><br>
    </tr>
    <tr>
        <th>Device_version_id</th>
        <td><input type="number" name="Device_version_id" value='<?php echo $fetch['Device_version_id']?>'></td>
    </tr>
    <tr>
        <td><input type="submit" name="submit" value="submit"></td><br>
    </tr>
    <tr>
        <td><button><a href="whiledev.php">back</a></button></td>
    </tr>
        </form>      
</table></body>


        