<?php
$Device_info_id=$_POST['Device_info_id'];
// echo Device_info_id;
$Device_name=$_POST['Device_name'];
// echo $Device_name;
$Device_mac_id=$_POST['Device_mac_id'];
// echo $Device_mac_id;
$Device_version_id=$_POST['Device_version_id'];
// echo $Device_version_id;

$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$update="update device_info set Device_name='$Device_name',Device_mac_id='$Device_mac_id',Device_version_id='$Device_version_id' where Device_info_id='$Device_info_id'";
mysqli_query($conn,$update);
 ?>
<style>
    table,th,td{
        border:1px solid blue;
    }
</style>
<table style="border-collapse: collapse;">
<tr>
<th>Device_name</th>
<th>Device_mac_id</th>
<th>Device_version_id</th>
</tr>
<tr>
<td><?php echo $Device_name;?> </td>
<td><?php echo $Device_mac_id;?></td>
<td><?php echo $Device_version_id;?></td>
</tr>
