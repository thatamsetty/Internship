<html>
<body>
	<h1><?php echo'hello';?></h1>
</body>
</html>	