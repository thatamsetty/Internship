<?php
$mo_no=$_POST['mobile_no'];
echo $mo_no;
$Name=$_POST['Name'];
echo $Name;
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$insert="insert into user(`mobile_no`,`Name`) values('123','aaa')";
mysqli_query($conn,$insert);
// $insert1 ="insert into user(`mobile_no`) values('12')";
// mysqli_query($conn,$insert1);
?>