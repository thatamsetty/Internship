<?php
$mobile_no=$_POST['mobile_no'];
echo $mobile_no;
$password=$_POST['password'];
echo $password;
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select= "select * from register where mobile_no='$mobile_no'and password='$password'";
$fetch=mysqli_fetch_assoc(mysqli_query($conn,$select)); // reading single row of data

 if(isset($fetch['mobile_no'])){
	echo "login sucessful";
	echo '<a href="meter1.html"><button>Back to homepage</button></a>';
    }
 else{
	echo "Not registered";
	echo '<a href="login1.html"><button>Back to homepage</button></a>';
     }
?>