<?php
$name=$_POST['name'];
echo $name;
$mobile_no=$_POST['mobile_no'];
echo $mobile_no;
$age=$_POST['age'];
echo $age;
$password=$_POST['password'];
echo $password;
$address=$_POST['address'];
echo $address;
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$insert="insert into register(`mobile_no`,`age`,`name`,`password`,`address`) values('$mobile_no','$age','$name','$password','$address')";
mysqli_query($conn,$insert);
?>