<?php
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select="select * from user";
$query=mysqli_query($conn,$select);
while($row=mysqli_fetch_assoc($query)){
	echo $row['Name'].'<br>';
}
?>