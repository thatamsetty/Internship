<style>
	table,th,td{
		border:1px solid red;
	}
</style>
<center>
<table style="width:50%;border-collapse: collapse;" >
	<h1>USER DETAILS</h1>
	<tr>
		<th>ID</th>
		<th>name</th>
		<th>mobile_no</th>
		<th>password</th>
		<th>address</th>
		<th>age</th>
		<th>Delete</th>
		<th>Update</th>
	</tr>
</center>
<?php
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select="select * from user";
$data=mysqli_query($conn,$select);
while($row=mysqli_fetch_assoc($data)){?>

<tr><form method="POST" action="update.php">
	<td><?php echo $row['user_id'];?><input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>"></td>
	<td><?php echo $row['Name'];?> </td>
	<td><?php echo $row['mobile_no'];?></td>
	<td><?php echo $row['address'];?></td>
	<td><?php echo $row['password'];?></td>
	<td><?php echo $row['age'];?></td>
	<td> <button type="submit" name="delete">Delete</button><!--<input type='submit' name='delete' value='delete'>--></td>
	<td><button type="submit" name="update ">Update</button><!--<input type='submit' name='update' value='update'>--></td>
    </form>
</tr>
<?php } ?></table>




