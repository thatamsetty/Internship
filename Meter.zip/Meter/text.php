<?php
$a=['$a',1,'hema'];
for each($a as $c){
	echo $c.'<br>';
}
?>s