<?php
$user_id=$_POST['user_id'];
// echo $user_id;
// $Name=$_POST['Name'];
// echo $Name;
// $mobile_no=$_POST['mobile_no'];
// echo $mobile_no;
// $password=$_POST['password'];
// echo $password;
// $address=$_POST['address'];
// echo $address;
// $age=$_POST['age'];
// echo $age;
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select="select * from user where  user_id='$user_id'";

//$data=mysqli_query($conn,$select);
$fetch=mysqli_fetch_assoc(mysqli_query($conn,$select));



// echo $fetch['Name'];
// echo $fetch['address'];
// <form method="POST" action="update.php">
// 	<input type="number" name="user_id" placeholder="user_id">
// 	<input type="text" name="Name" placeholder="Name">
// 	<input type="number" name="mobile_no" placeholder="mobile_no">
// 	<input type="password" name="password" placeholder="password">
// 	<input type="text" name="address" placeholder="address">
// 	<input type="number" name="age" placeholder="age">
// </form>
?>

<form method='POST' action='update1.php'>
<input type="hidden" name="user_id" value='<?php echo $fetch['user_id']?>'>
<th>name</th>
<input type="text" name="name" value='<?php echo $fetch['Name']?>'><br>
<th>password</th>
<input type="text" name="password" value='<?php echo $fetch['password']?>'><br>
<th>mobile_no</th>
<input type="number" name="mobile_no" value='<?php echo $fetch['mobile_no']?>'><br>
<th>address</th>
<input type="text" name="address" value='<?php echo $fetch['address']?>'><br>
<th>age</th>
<input type="number" name="age" value='<?php echo $fetch['age']?>'><br>
<input type="submit" name="submit" value="update">
</form>