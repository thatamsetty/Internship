<?php
$user_id=$_POST['user_id'];
// echo $user_id;
$name=$_POST['name'];
// echo $name;
$mobile_no=$_POST['mobile_no'];
// echo $mobile_no;
$address=$_POST['address'];
// echo $address;
$password=$_POST['password'];
// echo $password;
$age=$_POST['age'];
// echo $age;
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$update="update user set name='$name',mobile_no='$mobile_no',address='$address',password='$password',age='$age' where user_id='$user_id'";
mysqli_query($conn,$update);
 ?>
<style>
	table,th,td{
		border:1px solid blue;
	}
</style>
<table style="border-collapse: collapse;">
<tr>
<th>name</th>
<th>mobile_no</th>
<th>address</ th>
<th>password</th>
<th>age</th>
</tr>
<tr>
<td><?php echo $name;?> </td>
<td><?php echo $mobile_no;?></td>
<td><?php echo $address;?></td>
<td><?php echo $password;?></td>
<td><?php echo $age;?></td>
</tr>
