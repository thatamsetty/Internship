<?php
$a=0;
while($a<3){
	echo "the number is: $a <br>";
if ($a==2){
break;
 }
	$a++;
}
?>