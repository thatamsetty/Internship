
<style>
	body{
		margin:0;
		fornt-family:Arial,helvetica,sans-serif;
	}
	.topnav{
		overflow: hidden;
		background-color: black;
	}

    .topnav a{
    	float:left;
    	color:lightskyblue;
    	text-align: center;
    	padding: 10px 16px;
    	text-decoration: none;
    	fornt-size:15px;
    }
    .topnav a:hover {
    	background-color:blueviolet;
    	color:greenyellow;
    }
    .topnav a.active{
    	background-color:blue;
    	color:beige;
    }

</style>

	<center><h1 style="background-color: skyblue;">METER</h1></center>
	<h2><marquee width="100%" direction="rtl" style="background-color: yellow";fornt-size:29px;>DEVICE DETAILS</h2></marquee>
<body>
	<div class="topnav">
	    <a class="active" href="#home">Home</a>
		<a href="devicereg.html">Register</a>
		<a href="whiledev.php">device_info</a>
		<a href="aboutdev.html">about device</a>
		<a href="contacts">contact</a>
	</div>
<style>
	table,th,td{
		border:1px solid red;
	}
</style>
<center>
<table style="width:50%;border-collapse: collapse;" >
	<h1>DEVICE DETAILS</h1>
	<tr>
		<th>Device_info_id</th>
		<th>Device_name</th>
		<th>Device_mac_id</th>
		<th>Device_version_id</th>
		<th>Edit</th>
		
		
		</tr>
</center>
<?php
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select="select * from device_info";
$data=mysqli_query($conn,$select);
while($row=mysqli_fetch_assoc($data)){?>
<tr>
	<form method="POST" action="devicesd.php">
	<td><?php echo $row['Device_info_id'];?><input type="hidden" name="Device_info_id" value="<?php echo $row['Device_info_id']; ?>"></td>
	<td><?php echo $row['Device_name'];?> </td>
	<td><?php echo $row['Device_mac_id'];?></td>
	<td><?php echo $row['Device_version_id'];?></td>
	<td><input type="submit"  value="Edit"></td>
    </form>
</tr>


<?php } ?></table>
<tr>
	<td><button><a href="dhome.html">back</a></button></td>
</tr>