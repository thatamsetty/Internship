<html>
<body>
<center>
	<form method="POST" action="">
	<label for="">Date</label>
	<input type="month"  name="Datetime"><br><br>
	<input type="submit" name="submit">
    </form>
</body>
<style>
	table,th,td{
		border:1px solid red;
	}
</style>
</center>
<table style="border-collapse: collapse;width=50%">
<h1>Device_info</h1>
<tr>
	<th>Device_info_id</th>
	<th>Device_name</th>
	<th>Device_version_id</th>
	<th>Device_mac_id</th>
	<th>Datetime</th>
</tr>
<?php
if(isset($_POST['Datetime'])){
$a=$_POST['Datetime'];
$conn=mysqli_connect("localhost","thrinethra","12345678","meter");
$select="select * from device_info where Datetime like '$a%'";
$data=mysqli_query($conn,$select);
while($row=mysqli_fetch_assoc($data)){?>
<tr>
	<td><?php echo $row ['Device_info_id'];?></td>
	<td><?php echo $row['Device_name'];?></td>
	<td><?php echo $row['Device_mac_id'];?></td>
	<td><?php echo $row['Device_version_id'];?></td>
	<td><?php echo $row['Datetime'];?></td>
</tr>
</body>
<?php } }?>
</table>

</html>